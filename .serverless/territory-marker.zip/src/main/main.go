package main

import (
	"log"
	"encoding/json"
	"errors"
	"context"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/feature/dynamodb/attributevalue"
	"github.com/aws/aws-sdk-go-v2/service/dynamodb"
)

type Territory struct {
	name string
}

func main() {
	lambda.Start(handler)
}

func handler(request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	log.Println("Function Invoked")
  cfg, err := config.LoadDefaultConfig(context.TODO(), func(o *config.LoadOptions) error {
		o.Region = "us-east-2"
		return nil
	})

	if err != nil {
		panic(err)
	}
	svc := dynamodb.NewFromConfig(cfg)

	result, err := svc.Scan(context.TODO(), &dynamodb.ScanInput{
		TableName: aws.String("territories"),
	})

	if err != nil {
			log.Fatalf("Got error calling GetItem: %s", err)
	}

	if result == nil {
		msg := "Could not find Item"
		return events.APIGatewayProxyResponse{}, errors.New(msg)
	}

	items := []Territory{}
	err = attributevalue.UnmarshalListOfMaps(result.Items, &items)
	if err != nil {
			panic(err)
	}

	itemJson, err := json.Marshal(items)
	if err != nil {
			panic(err)
	}

  return events.APIGatewayProxyResponse{Body: string(itemJson), StatusCode: 200}, nil
}